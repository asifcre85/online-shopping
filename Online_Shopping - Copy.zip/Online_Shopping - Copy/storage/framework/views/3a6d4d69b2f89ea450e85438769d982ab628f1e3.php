<!--Footer-part-->

<div class="row-fluid">
    <div id="footer" class="span12"> 2018 &copy; Hyper-Mart Admin </div>
  </div>
  
  <!--end-Footer-part-->